<?php
  // indiquez les identifiants de votre base de données IUT
  define("HOSTNAME", "localhost");
  define("DATABASE", "saes3-cgelin");   // votre identifiant court
  define("LOGIN", "saes3-cgelin");      // votre identifiant court
  define("PASSWORD", "PG/arObPST7m8OFp");      // votre mot de passe
?>
