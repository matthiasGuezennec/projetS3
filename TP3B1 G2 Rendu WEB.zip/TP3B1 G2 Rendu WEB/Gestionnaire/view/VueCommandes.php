<ul>
    <?php foreach($produits as $prod):    ?>
        <li>
            <?php echo $prod; ?>
        </li>
        <?php endforeach; ?>
</ul>